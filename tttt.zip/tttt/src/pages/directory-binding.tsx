/** @jsxImportSource @emotion/react */
import React from 'react';

function DirectoryBinding() {
  return <div>目录绑定</div>;
}

export default DirectoryBinding;
