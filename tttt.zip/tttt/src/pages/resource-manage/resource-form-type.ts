export interface ISubmitData {
  resource_name: string;
  resource_classify: string;
  resource_code: string;
  resource_statue: 0 | 1;
  resource_address: string;
  resource_remark: string;
}
