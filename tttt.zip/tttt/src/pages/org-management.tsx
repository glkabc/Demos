/** @jsxImportSource @emotion/react */
import * as React from 'react';

function OrgManagement() {
  return <div>OrgManagement</div>;
}

export default OrgManagement;
