/** @jsxImportSource @emotion/react */

function NoMatchDashboard() {
  return <div role="alert">No Match</div>;
}

export default NoMatchDashboard;
