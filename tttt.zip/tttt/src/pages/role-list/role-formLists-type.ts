interface RoleFormListsType {
  role_name?: string | undefined;
  role_code?: number | undefined;
  role_comments?: string | undefined;
}
export default RoleFormListsType;
