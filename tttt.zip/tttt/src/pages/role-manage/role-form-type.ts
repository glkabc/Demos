interface RoleForm {
  role_name: string;
  resource_number: string;
  resource_name: string;
  role_description: string;
  role_status: string;
}

export default RoleForm;
