import easyId from './easy-id';

export { easyId };
